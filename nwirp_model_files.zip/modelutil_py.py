'''
Date: 2/8/2019
Author: Bulbul Ahmmed
This is a script to modify model input file
based on newly created parameter.
'''
import numpy as np
import pandas as pd
from pandas import DataFrame

ref1 = open('hk_u.ref', 'r')
ref2 = open('hk_l.ref', 'r')
upw = open('nwirp.upw', 'r')
new = open('nwirp.upw.next', 'w+')

                                                                                                           
line1 = pd.read_csv('nwirp.upw', skiprows=204, skipfooter=196, engine='python') 
line2 = pd.read_csv('nwirp.upw', skiprows=401, skipfooter=0, engine='python')       

def chunker(datframe, size):
    return (datframe[pos:pos + size] for pos in range(0, len(datframe), size))

def get_params(file, chunksize):
    newlist=[]
    dat  = np.genfromtxt(file)
    df  = DataFrame(dat)
    for chunk in chunker(df, chunksize):
        to_list = chunk.values.tolist()
        newlist.append(to_list)
    param = np.reshape(np.asarray(newlist), (194, 63))
    return param

param1 = get_params(ref1, 18)
param2 = get_params(ref2, 18)

i = 0
while i < 10:
    line = upw.readline()
    new.write(str(line))
    i = i + 1 
 
np.savetxt(new, param1, fmt='%.18e', delimiter=' ')
line1.to_csv(new, index=False)
np.savetxt(new, param2, fmt='%.18e', delimiter=' ')
line2.to_csv(new, index=False)
  
    

ref1.close()
ref2.close()
upw.close()
new.close()